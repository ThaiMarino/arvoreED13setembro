package aulaArvore;

public class No {
	
	private int valor;
	private No esq;
	private No dir;
	private No meio;
	
	//criacao dos vetores em que o nó apontará
	No (int valor){
		this.valor = valor;
		this.esq = null;
		this.dir = null;
		this.meio = null;
	}
	
	@Override
	public String toString() {
		return "No [valor=" + valor + "]";
	}

	public void setEsq(No esq) {
		this.esq = esq;
	}

	public void setDir(No dir) {
		this.dir = dir;
	}
	
	public void setMeio(No meio) {
		this.meio = meio;
	}
	
	public No getEsq() {
		return this.esq;
	}
	
	public No getDir() {
		return this.dir;
	}
	
	
	public void preOrdem(No raiz) {
		//1 passo: imprimir raiz
		//Esquerda
		//Direita
		
		
		if (raiz != null) {
			
		System.out.print(raiz + " ");
		preOrdem(raiz.getEsq());
		preOrdem(raiz.getDir());
		
		
	}
	}
	
	public void emOrdem(No raiz) {
		//1 passo: imprimir raiz
		//direita
		//esquerda
		
		if (raiz != null) {
		
		emOrdem(raiz.getEsq());
		System.out.print(raiz + " ");
		emOrdem(raiz.getDir());
	}
	}
	
	public void posOrdem(No raiz) {
		//1 passo: imprimir raiz
		//direita
		//esquerda
		
		if (raiz != null) {
		
		posOrdem(raiz.getDir());
		posOrdem(raiz.getEsq());
		System.out.print(raiz + " ");
	}
	}
}


